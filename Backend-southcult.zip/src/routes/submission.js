import express from "express";
import multer from "multer";
import cloudinary from "../config/cloudinary.js";
import streamifier from "streamifier";
import pool from "../config/database.js";
import transporter from "../config/mailer.js";
const router = express.Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 500 * 1024 * 1024,
  },
});

const allowedTypes = [
  "audio/mpeg",
  "audio/wav",
  "audio/x-wav",
  "video/mp4",
  "video/quicktime",
  "application/pdf",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
];

const allowedCategories = [
  "Music",
  "Film",
  "Documentary",
  "Script",
  "Visual Art",
];

router.post("/", upload.single("file"), async (req, res) => {
  try {
    console.log("========== NEW SUBMISSION ==========");
    console.log("BODY:", req.body);
    console.log("FILE:", req.file);

    const {
      name,
      email,
      phone,
      city,
      category,
      title,
      about,
      portfolio,
    } = req.body;

    // -----------------------------
    // VALIDATION
    // -----------------------------

    if (
      !name?.trim() ||
      !email?.trim() ||
      !phone?.trim() ||
      !category?.trim()
    ) {
      return res.status(400).json({
        success: false,
        message: "Name, email, phone and category are required.",
      });
    }

    if (!allowedCategories.includes(category)) {
      return res.status(400).json({
        success: false,
        message: "Invalid category selected.",
      });
    }

    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: "Please upload your work.",
      });
    }

    if (!allowedTypes.includes(req.file.mimetype)) {
      return res.status(400).json({
        success: false,
        message: `Unsupported file type: ${req.file.mimetype}`,
      });
    }

    if (req.file.size === 0) {
      return res.status(400).json({
        success: false,
        message: "The uploaded file is empty.",
      });
    }

    // -----------------------------
    // CLOUDINARY UPLOAD
    // -----------------------------

    console.log("Uploading file to Cloudinary...");

    const uploadResult = await new Promise((resolve, reject) => {
      const resourceType = req.file.mimetype.startsWith("video")
        ? "video"
        : "raw";

      const stream = cloudinary.uploader.upload_stream(
        {
          folder: "southcult/submissions",
          resource_type: resourceType,
          use_filename: true,
          unique_filename: true,
        },
        (error, result) => {
          if (error) {
            console.error("CLOUDINARY ERROR:", error);
            reject(error);
          } else {
            resolve(result);
          }
        }
      );

      streamifier
        .createReadStream(req.file.buffer)
        .pipe(stream);
    });

    console.log("Cloudinary upload successful:");
    console.log(uploadResult.secure_url);

    // -----------------------------
    // SAVE TO MYSQL
    // -----------------------------

    console.log("Saving submission to MySQL...");

    const [result] = await pool.execute(
      `
      INSERT INTO submissions (
        name,
        email,
        phone,
        city,
        category,
        title,
        about,
        portfolio,
        file_name,
        file_type,
        file_size,
        cloudinary_public_id,
        cloudinary_url
      )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        name.trim(),
        email.trim(),
        phone.trim(),
        city?.trim() || null,
        category,
        title?.trim() || null,
        about?.trim() || null,
        portfolio?.trim() || null,
        req.file.originalname,
        req.file.mimetype,
        req.file.size,
        uploadResult.public_id,
        uploadResult.secure_url,
      ]
    );

   console.log("MySQL insert successful.");
console.log("Submission ID:", result.insertId);

// -----------------------------
// SEND EMAIL TO SUBMITTER
// -----------------------------

console.log("Sending confirmation email...");

await transporter.sendMail({
  from: `"SouthCult" <${process.env.EMAIL_USER}>`,
  to: email.trim(),
  subject: "SouthCult — Your Work Submission",
  html: `
    <!DOCTYPE html>
    <html>
      <body style="margin:0; padding:0; background:#050505; color:#ffffff; font-family:Arial, sans-serif;">
        <div style="max-width:600px; margin:40px auto; padding:30px; background:#111111; border-radius:16px;">

          <h1 style="margin:0 0 20px; font-size:28px;">
            Submission Received
          </h1>

          <p style="color:#cccccc; line-height:1.6;">
            Hi ${name.trim()},
          </p>

          <p style="color:#cccccc; line-height:1.6;">
            Thank you for submitting your work to SouthCult.
            We have successfully received your submission.
          </p>

          <div style="margin:25px 0; padding:20px; background:#1a1a1a; border-radius:12px;">
            <p style="margin:0 0 10px; color:#999999;">
              Project
            </p>

            <p style="margin:0; font-size:18px;">
              ${title?.trim() || "Untitled Project"}
            </p>

            <p style="margin:15px 0 0; color:#999999;">
              Category: ${category}
            </p>
          </div>

          <p style="color:#cccccc;">
            Your uploaded file:
          </p>

          <a
            href="${uploadResult.secure_url}"
            target="_blank"
            style="
              display:inline-block;
              padding:14px 22px;
              background:#ffffff;
              color:#000000;
              text-decoration:none;
              border-radius:999px;
              font-weight:bold;
            "
          >
            View Submitted Work
          </a>

          <p style="margin-top:30px; color:#888888; font-size:13px; line-height:1.6;">
            We usually respond within 2–3 weeks.
          </p>

          <p style="color:#888888; font-size:13px;">
            — SouthCult
          </p>

        </div>
      </body>
    </html>
  `,
});

await transporter.sendMail({
  from: `"SouthCult Submissions" <${process.env.EMAIL_USER}>`,
  to: process.env.CLIENT_EMAIL,
  subject: `New Work Submission — ${category} — ${title?.trim() || "Untitled Project"}`,
  html: `
    <!DOCTYPE html>
    <html>
      <body style="
        margin:0;
        padding:0;
        background:#050505;
        color:#ffffff;
        font-family:Arial,sans-serif;
      ">

        <div style="
          max-width:650px;
          margin:40px auto;
          padding:30px;
          background:#111111;
          border-radius:16px;
        ">

          <h1 style="margin:0 0 25px;">
            New Work Submission
          </h1>

          <p style="color:#cccccc;">
            A new submission has been received through the SouthCult website.
          </p>

          <div style="
            margin-top:25px;
            padding:20px;
            background:#1a1a1a;
            border-radius:12px;
          ">

            <p>
              <strong>Name:</strong><br>
              ${name.trim()}
            </p>

            <p>
              <strong>Email:</strong><br>
              ${email.trim()}
            </p>

            <p>
              <strong>Phone:</strong><br>
              ${phone.trim()}
            </p>

            <p>
              <strong>City / State:</strong><br>
              ${city?.trim() || "Not provided"}
            </p>

            <p>
              <strong>Category:</strong><br>
              ${category}
            </p>

            <p>
              <strong>Project Title:</strong><br>
              ${title?.trim() || "Untitled Project"}
            </p>

            <p>
              <strong>About:</strong><br>
              ${about?.trim() || "Not provided"}
            </p>

            <p>
              <strong>Portfolio:</strong><br>
              ${
                portfolio?.trim()
                  ? `<a href="${portfolio.trim()}" target="_blank">${portfolio.trim()}</a>`
                  : "Not provided"
              }
            </p>

            <p>
              <strong>Original File:</strong><br>
              ${req.file.originalname}
            </p>

            <p>
              <strong>File Type:</strong><br>
              ${req.file.mimetype}
            </p>

            <p>
              <strong>File Size:</strong><br>
              ${(req.file.size / (1024 * 1024)).toFixed(2)} MB
            </p>

          </div>

          <div style="margin-top:25px;">

            <p style="color:#cccccc;">
              Uploaded Work:
            </p>

            <a
              href="${uploadResult.secure_url}"
              target="_blank"
              style="
                display:inline-block;
                padding:14px 22px;
                background:#ffffff;
                color:#000000;
                text-decoration:none;
                border-radius:999px;
                font-weight:bold;
              "
            >
              View Submitted Work
            </a>

          </div>

          <p style="
            margin-top:30px;
            color:#777777;
            font-size:13px;
          ">
            Submission ID: ${result.insertId}
          </p>

        </div>

      </body>
    </html>
  `,
});
console.log("Confirmation email sent successfully.");

console.log("========== SUBMISSION COMPLETE ==========");

return res.status(201).json({
  success: true,
  message: "Submission received successfully. A confirmation email has been sent.",
  submissionId: result.insertId,
  fileUrl: uploadResult.secure_url,
});
  } catch (error) {
    console.error("========== SUBMISSION ERROR ==========");
    console.error(error);
    console.error("======================================");

    return res.status(500).json({
      success: false,
      message: "Unable to process submission.",
      error:
        process.env.NODE_ENV === "development"
          ? error.message
          : undefined,
    });
  }
});

export default router;