import "dotenv/config";
import express from "express";
import cors from "cors";

import submissionsRoute from "./routes/submission.js";

const app = express();

const PORT = process.env.PORT || 5000;

app.use(
  cors({
    origin: true,
    credentials: true,
  })
);

app.use(express.json());

app.get("/", (req, res) => {
  res.json({
    success: true,
    message: "SouthCult API is running.",
  });
});

app.use("/api/submissions", submissionsRoute);

app.listen(PORT, () => {
  console.log(`SouthCult API running on port ${PORT}`);
});